package pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASSES.wait_type;

public class home_page {

	
WebDriver dr;
	
wait_type wt;
	//By profile_xp=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");

By from=By.xpath("//input[@id='src']");
By from_select=By.xpath("//li[@select-id='results[1]']");

By dest=By.xpath("//input[@id='dest']");
By dest_select=By.xpath("//li[@data-id='66298']");

By click_ondate=By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']");

By search=By.xpath("//button[@id='search_btn']");
	
	public home_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void from(String fr)
	{    
		wt=new wait_type();
		WebElement fr_en=wt.waitForElement(from, 20);
		fr_en.sendKeys(fr);
		
		
		
       WebElement web_fro=wt.elementToBeClickable(from_select, 20);
		web_fro.click();	
    
  
	}
	
	public void to(String des)
	{
		WebElement des_en=wt.waitForElement(dest, 20);
		des_en.sendKeys(des);
		
		WebElement dc=wt.elementToBeClickable(dest_select, 20);
		dc.click();
		
	}
	
	
	public void ondate(String ond) {
		dr.findElement(click_ondate).click();
		
		String exp_data=ond;
		System.out.println(exp_data);
		int l=exp_data.length();
		String d=exp_data.substring(1, l=l-1);
		System.out.println(d);
		
		
        String[] arrOfStr = d.split("-", 3); 
  
        for (String a : arrOfStr) 
            System.out.println(a); 
        
          String exp_date=arrOfStr[0];
          String exp_month=arrOfStr[1];
          String exp_year=arrOfStr[2];
          String p=exp_month+" ";
          String q=p+exp_year;
          
          dr.findElement(By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']")).click();
      	String act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();
      	
      	while(!act_year.equals(q))      	{
      		dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[3]")).click();
      		act_year=dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[2]")).getText();


      	}
      	
      	List <WebElement> rb=dr.findElements(By.xpath("//table[@class='rb-monthTable first last']//child::td"));
      	
      	for(WebElement el:rb)
      	{
      		String date=el.getText();
      		if(exp_date.equals(date))
      		{
      			el.click();
      		}
	    }
		     	
	}
	
	public void search()
	{
		dr.findElement(search).click();	
	}
	
	public void sel(String f,String t,String o) {
		this.from(f);
		this.to(t);
		this.ondate(o);
		this.search();
	}
	
	
}
