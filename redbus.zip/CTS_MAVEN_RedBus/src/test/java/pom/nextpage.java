package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class nextpage {

	WebDriver dr;
	
	By ac=By.xpath("//ul[@class='list-chkbox']/li[3]");
	By sec_name=By.xpath("//li[@id='9026206']/div[1]/div[1]/div[1]/div[1]/div[1]");
	By sec_price=By.xpath("//li[@id='9026206']/div[1]/div[1]/div[1]/div[6]/div/div/span");
	
	public nextpage(WebDriver dr)
	{
		this.dr=dr;
	}
	public void ac()
	{
		dr.findElement(ac).click();
	}
	
	public String sn()
	{
		return dr.findElement(sec_name).getText();
	}
	
	public String sp()
	{
		return dr.findElement(sec_price).getText();
	}
	
	public void read()
	{
		this.ac();
		this.sn();
		this.sp();
	}
	
}
