package pom_test;



import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.utilities;
import pom.home_page;
import pom.nextpage;


public class Test_login_chr extends utilities{
	
	
	
	home_page hp;
	nextpage np;
	
	@BeforeMethod
	public void launch_brow()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("https://www.redbus.in/");
	}
	
//  @Test(priority=0)
//  public void test_loginpage() {
//	  
//	  lp=new login_page(dr);
//	  String lp_title=lp.get_title();
//	  Assert.assertTrue(lp_title.contains("Shop"));
//  }
  
  @Test(dataProvider="login")
  public void test(String from, String to, String ondate) {
	  
	  hp=new home_page(dr);
	  np=new nextpage(dr);
	  
	  hp.sel(from, to, ondate);
	  
	  String secname=np.sn();
	  System.out.println(secname);
	  
	  String secprice=np.sp();
	  System.out.println(secprice);
	  
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(secname, "DreamLiner Travels");
	sa.assertAll();
  }
  
  @DataProvider(name="login")
	public String[][] prov_data(){
	  
	  get_test_data();
		return testdata;
	}
  
  @AfterMethod
  public void am() {
	  dr.close();
  }
}
